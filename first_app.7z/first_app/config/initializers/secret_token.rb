# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FirstApp::Application.config.secret_token = '011a9a17e6efd17a43a118d6d3c2014d377a89f4b7b2b386d121c655157f6593006484c41cb8f59fe66f1b4bb6910b70b03a48f096ac2429146d70b2956e57f0'
